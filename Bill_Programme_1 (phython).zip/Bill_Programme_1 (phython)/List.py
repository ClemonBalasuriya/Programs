print('Press 1 to add items. \nPress 2 to create new Price List')
while True:
    try:
        choice=int(input(('Enter the choice: ')))
        if choice == 1 or choice == 2:
            break
        
    except:
        
        continue

def add_list_2():
    global I
    while True:
        try:
            I = input('Press "A" to add another or press "Q" to quiet: ')
            I = I.upper()
                    
                        
            if I == "Q" or I =="A":
                break
            else :
                continue
            break
                            
                            
        except:
            continue
        


        
def add_list():
        global Iterm
        global ITERM
        global Price

##    while True:
        Iterm= input('Input iterm: ')
        ITERM = str(Iterm[:1])
            
            
        while True:
            try:
                Price= int(input('Price: '))
                break
            except:
                print('Invalid. Enter the price: ')

  


def write_file():            
    import json#https://www.geeksforgeeks.org/write-a-dictionary-to-a-file-in-python/
    with open('price_list','w') as convert_file:
        convert_file.write(json.dumps(Prices))
    with open('Price_list(f)','w') as convert_file:
        convert_file.write(json.dumps(prices))

n=True
if n:
    try:
        if choice == 2:
            prices={}
            Prices={}
            while True:
                add_list()
                prices.update({Iterm : Price})
                Prices.update({ITERM : Price})

                add_list_2()
                if I == 'A':
                    continue
                else:
                    break
            write_file()

        else:
            while True:
                import json                                         #https://www.geeksforgeeks.org/how-to-read-dictionary-from-file-in-python/
                with open('price_list') as f:                       #read the list file
                    data = f.read()
                js = json.loads(data)
                with open('price_list(f)') as fa:                       #read the list file
                    dataa = fa.read()
                jss = json.loads(dataa)
                
                add_list()

                if ITERM in js:                                 #add the count to a dictionary

                    js.update({ITERM:Price})
                    jss.update({Iterm:Price})
                    with open('price_list','w') as f:
                        f.write(json.dumps(js))
                    with open('Price_list(f)','w') as fa:
                        fa.write(json.dumps(jss))
                    
                    
                else:
                    js.update({ITERM:Price})
                    jss.update({Iterm:Price})
                    with open('price_list','w') as f:
                        f.write(json.dumps(js))
                    with open('Price_list(f)','w') as fa:
                        fa.write(json.dumps(jss))
                    
                

                f.close()
                fa.close()
                add_list_2()
                if I == 'A':
                    continue
                else:
                    break
            import json#https://www.geeksforgeeks.org/write-a-dictionary-to-a-file-in-python/
            with open('price_list','w') as convert_file:
                convert_file.write(json.dumps(js))
            with open('Price_list(f)','w') as convert_file:
                convert_file.write(json.dumps(jss))
            n= False

    except:
        print('Their is no list. Pls create a list!!!')
            

