not_in_priceLists=list()
all_not_in_priceLists=list()
total = 0
X=0
y=0
iterm_price=0
History={}
    
        
def calculate_iterm_price(item):
    global count
        
    price= item * count
    return price

    
def return_count():
    while True:
        try:
            global count
            count = int(input('How many: '))
                
            break
                
        except:
            continue
        
while True:
    while True:                                                 #calculate the iterm price
        try:
            while True:
                item = input('\nEnter the iterm Code: ')
                if item != '':
                    break
              
            import json                                         #https://www.geeksforgeeks.org/how-to-read-dictionary-from-file-in-python/
            with open('price_list') as f:                       #read the list file
                data = f.read()
            js = json.loads(data)

            iterm_price = js[item]
            f.close()
            return_count()
            if item in History:                                 #add the count to a dictionary
                q=History[item]
                counts= q+count
                History.update({item:counts})
            else:
                History[item]=count
                
            

            X=calculate_iterm_price(iterm_price)
                
                
               
            
        except ValueError:
            print('Error. Try again !!!')
            continue
        except:
            print('It\'s not in the list')
            
            while True:
                try:
                    not_in_priceList = input('If you need to add item.Pls enter "A". Else press Enter.')
                        
                    if not_in_priceList == 'A' or not_in_priceList == 'a':
                        while True:
                            try:
                                iterm_price = int(input('Enter the price: '))
                                not_in_priceLists.append(item)
                                not_in_priceLists.append(iterm_price)
                                return_count()
                                not_in_priceLists.append(count)

                                
                                all_not_in_priceLists.append(not_in_priceLists)
                                with open("not_saveList_file", "a") as fp:          #https://pynative.com/python-write-list-to-file/
                                    for item in all_not_in_priceLists:
                                        fp.write("%s\n" % item)
                                not_in_priceLists=[]
                                all_not_in_priceLists=[]
                                y=calculate_iterm_price(iterm_price)
                                
                                        

                                break
                            except:
                                continue
                                
                    elif not_in_priceList == '':
                        break
                    else:
                            
                        continue
                    break
                except:
                        
                    continue
        total=total+X+y
        print('\nTotal:',total)
        X=0
        y=0
        iterm_price=0
        continue_or_not=input('Press "Q" to end or Press Enter to continue: ')
        if continue_or_not == 'Q' or continue_or_not == 'q':
            
            try:
                import json
                with open('List_History_file','r')as convert_file:
                    r = convert_file.read()
                add = json.loads(r)
                print(add.keys())
                l1=list(add.keys())
                l2=list(History.keys())
                print(l2)
                same=set(l1) & set(l2)
                for x in same:
                    n1=add.get(x)
                    print(n1)
                    n2=History.get(x)

                    History.update({x:n2})
                    del add[x]
                def Merge(History,add):
                    res={**History,**add}
                    return res
                finel_li=Merge(History,add)
                print(finel_li)

                    






                    



                convert_file.close()
                with open('List_History_file','w')as convert_file:
                    
                    convert_file.write(json.dumps(finel_li))
                    convert_file.close()


            except:
                import json
                print('dddddddddddddddddd')
                with open('List_History_file','w')as convert_file:
                    convert_file.write(json.dumps(History))
                    convert_file.close()

            print('*'*25,'The end','*'*25)
            total=0


            



