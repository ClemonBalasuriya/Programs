package com.example.program1;


import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;

import static com.example.program1.HelloController.*;

public class RemoveTableController {
    @FXML
    private TableColumn<removeItemCode, String> colItem;

    @FXML
    private TableColumn<removeItemCode, String> colItemCode;

    @FXML
    private TableView<removeItemCode> tbRemoveItem;

    @FXML
    private TextField tfRemoveItemCode;

    @FXML
    private Button btRemoveItemCode;

    public void initialize(){
        tfRemoveItemCode.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfRemoveItemCode.getText().isEmpty()&& !tfRemoveItemCode.getText().equals("0")) {
                    for(String item : itemCodeList.keySet() ){

                        if(tfRemoveItemCode.getText().equals(itemCodeList.keySet().toString().substring(1,itemCodeList.keySet().toString().length()-1))){
                            String removeItemName=itemCodeList.get(item);
                            itemCodeList.remove(item);
                            priceList.remove(item);




                            colItemCode.setCellValueFactory(cellData -> cellData.getValue().removeItemCodeProperty());
                            colItem.setCellValueFactory(cellData -> cellData.getValue().removeItemProperty());
                            removeItemCode newRemoveTable = new removeItemCode(tfRemoveItemCode.getText().toString(),removeItemName);
                            tbRemoveItem.getItems().add(newRemoveTable);

                            tfRemoveItemCode.clear();
                            tfRemoveItemCode.requestFocus();
                            break;

                        }
                    }

                }
            }
        });

    }
    public void saveNewItemCode(){
        try {
            FileOutputStream itemCodes = new FileOutputStream("ItemCode.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemCodes);
            outputStream.writeObject(itemCodeList);
            outputStream.close();
            itemCodes.close();

            FileWriter writeFile = new FileWriter("Iterm Code.txt");                //save file to read
            for (String i : itemCodeList.keySet()) {
                writeFile.write(i+ " : " + itemCodeList.get(i)+" :  RS. " + priceList.get(i)+"\n");
                writeFile.flush();
            }
            writeFile.close();
        }catch (Exception e){
            System.out.println("Error in Item Code saving 1.");
        }
        try {
            FileOutputStream itemCodes = new FileOutputStream("ItemPrice.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemCodes);
            outputStream.writeObject(priceList);
            outputStream.close();
            itemCodes.close();

            Stage currentStage = (Stage) btRemoveItemCode.getScene().getWindow();
            currentStage.close();

        }catch (Exception e){
            System.out.println("Error in Item Code saving 2.");
        }


    }
}