package com.example.program1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.util.concurrent.atomic.AtomicReference;

import static com.example.program1.HelloController.*;


public class ChangePriceController {
    @FXML
    private Button btChangePrice;

    @FXML
    private TableColumn<changePriceTable, String> colChangeItem;

    @FXML
    private TableColumn<changePriceTable, String> colChangeItemCode;

    @FXML
    private TableColumn<changePriceTable, Double> colChangeItemPrice;

    @FXML
    private TableView<changePriceTable> tbChangePrice;

    @FXML
    private TextField tfChangeItemPrice;

    @FXML
    private TextField tfItemCode;
    public void initialize(){
        AtomicReference<String> ItemCode = new AtomicReference<>("0");
        AtomicReference<Double> item_price = new AtomicReference<>(0.0);

        tfItemCode.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfItemCode.getText().isEmpty()&& !tfItemCode.getText().equals("0")) {
                    tfChangeItemPrice.requestFocus();

                }
            }
        });
        tfChangeItemPrice.setOnKeyPressed((KeyEvent event) -> {
            String itemName ;
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfItemCode.getText().isEmpty() && !tfChangeItemPrice.getText().isEmpty() ) {
                    try{
                        ItemCode.set(tfItemCode.getText());
                        item_price.set(Double.parseDouble(tfChangeItemPrice.getText()));

                    }catch (Exception e){
                        tfChangeItemPrice.clear();
                        tfChangeItemPrice.requestFocus();
                        return;
                    }
                    for (String item: priceList.keySet()){
                        if (ItemCode.toString().equals(item)){
                            priceList.put(ItemCode.toString(),Double.parseDouble(item_price.toString()));

                            itemName = itemCodeList.get(item);

                            colChangeItemCode.setCellValueFactory(cellData -> cellData.getValue().itemCodeProperty());
                            colChangeItem.setCellValueFactory(cellData -> cellData.getValue().itemProperty());
                            colChangeItemPrice.setCellValueFactory(cellData -> cellData.getValue().priceProperty().asObject());

                            ObservableList<changePriceTable> currentTableData = tbChangePrice.getItems();
                            String currentItemId = tfItemCode.getText();

                            for(changePriceTable items: currentTableData){
                                if (items.getChangePriceItemCode().equals(currentItemId)){
                                    alert("Edit item what you change before.");
                                    items.setChangePrice(Double.parseDouble(tfChangeItemPrice.getText()));
//                            item.setNewPrice(Integer.parseInt(tfNewItemPrice.getText()));

                                    // Set the updated data to the table view
                                    tbChangePrice.setItems(FXCollections.observableArrayList(currentTableData));

                                    tfItemCode.clear();
                                    tfChangeItemPrice.clear();
                                    tfItemCode.requestFocus();
                                    return;
                                }
                            }
                            changePriceTable changePriceTB = new changePriceTable(ItemCode.toString(),itemName,Double.parseDouble(item_price.toString()));
                            tbChangePrice.getItems().add(changePriceTB);
                            tfItemCode.clear();
                            tfChangeItemPrice.clear();
                            tfItemCode.requestFocus();
                            break;
                        }
                    }



                }
            }


        });
    }

    @FXML
    void rowClick(MouseEvent event) {
        changePriceTable clickedRow = tbChangePrice.getSelectionModel().getSelectedItem();
        tfItemCode.setText(String.valueOf(clickedRow.getChangePriceItemCode()));
        tfChangeItemPrice.setText(String.valueOf(clickedRow.getChangePrice()));
    }
    public void alert(String displayMsg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        alert.setContentText(displayMsg);

        alert.showAndWait();
    }
    public void saveNewItemCodeAfterNewPrice(){

        try {
            FileOutputStream itemCodes = new FileOutputStream("ItemPrice.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemCodes);
            outputStream.writeObject(priceList);
            outputStream.close();
            itemCodes.close();
            FileWriter writeFile = new FileWriter("Iterm Code.txt");                //save file to read
            for (String i : itemCodeList.keySet()) {
                writeFile.write(i+ " : " + itemCodeList.get(i)+" :  RS. " + priceList.get(i)+"\n");
                writeFile.flush();
            }
            writeFile.close();
            Stage currentStage = (Stage) btChangePrice.getScene().getWindow();
            currentStage.close();

        }catch (Exception e){
            System.out.println("Error in Item Code saving .");
        }

    }
}

