package com.example.program1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static com.example.program1.HelloController.*;

public class NewAddTableController {
    @FXML
    private TableColumn<newAddTable, String> colNewItem;

    @FXML
    private TableColumn<newAddTable, String> colNewItemCode;

    @FXML
    private TableColumn<newAddTable, Integer> colNewItemPrice;

    @FXML
    private TableView<newAddTable> tbNewItemTable;

    @FXML
    private TextField tfNewItemCode;

    @FXML
    private TextField tfNewItemName;

    @FXML
    private TextField tfNewItemPrice;
    @FXML
    private Button btEditPrice;

    @FXML
    private Button btRemoveTable;
    @FXML
    private Button btAddNewItems;
    public void initialize(){

        AtomicReference<String> newItemCode = new AtomicReference<>("0");
        AtomicReference<String> newItemName = new AtomicReference<>("0");
        AtomicInteger newItemPrice= new AtomicInteger();
        tfNewItemCode.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfNewItemCode.getText().isEmpty()&& !tfNewItemCode.getText().equals("0")) {
                    tfNewItemPrice.requestFocus();
                }
            }
        });
        tfNewItemPrice.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                try{
                    if (!tfNewItemPrice.getText().isEmpty()&& !tfNewItemPrice.getText().isEmpty() && !(newItemCode.equals("0"))) {
                        tfNewItemName.requestFocus();
                    }
                }catch (Exception e){
                }
            }
        });
        tfNewItemName.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfNewItemName.getText().isEmpty()&& !tfNewItemName.getText().equals("0")&& !tfNewItemPrice.getText().isEmpty()) {
                    newItemCode.set(tfNewItemCode.getText());
                    newItemPrice.set(Integer.parseInt(tfNewItemPrice.getText()));
                    newItemName.set(tfNewItemName.getText());


                    itemCodeList.put(newItemCode.toString(),newItemName.toString());
                    priceList.put(newItemCode.toString(),Double.parseDouble(newItemPrice.toString()));

                    colNewItemCode.setCellValueFactory(cellData -> cellData.getValue().newItemCodeProperty());
                    colNewItem.setCellValueFactory(cellData -> cellData.getValue().newItemProperty());
                    colNewItemPrice.setCellValueFactory(cellData -> cellData.getValue().newPriceProperty().asObject());

                    ObservableList<newAddTable> currentTableData = tbNewItemTable.getItems();
                    String currentItemId = tfNewItemCode.getText();

                    for(newAddTable item: currentTableData){
                        if (item.getNewItemCode().equals(currentItemId)){
                            alert("Edit item what you add before.");
                            item.setNewItem(tfNewItemName.getText());
                            item.setNewPrice(Integer.parseInt(tfNewItemPrice.getText()));
                            // Set the updated data to the table view
                            tbNewItemTable.setItems(FXCollections.observableArrayList(currentTableData));

                            tfNewItemCode.clear();
                            tfNewItemName.clear();
                            tfNewItemPrice.clear();
                            tfNewItemCode.requestFocus();
                            return;
                        }
                    }


                    newAddTable newAddTable = new newAddTable(newItemCode.toString(),newItemName.toString(),Integer.parseInt(newItemPrice.toString()));
                    tbNewItemTable.getItems().add(newAddTable);

                    tfNewItemCode.clear();
                    tfNewItemName.clear();
                    tfNewItemPrice.clear();
                    tfNewItemCode.requestFocus();

//                    tbNewItemTable.getColumns().addAll(colNewItemCode,colNewItem,colNewItemPrice);



                }
            }
        });
    }

    @FXML
    void rowClick(MouseEvent event){
        newAddTable clickedRow = tbNewItemTable.getSelectionModel().getSelectedItem();
        tfNewItemCode.setText(String.valueOf(clickedRow.getNewItemCode()));
        tfNewItemName.setText(String.valueOf(clickedRow.getNewItem()));
        tfNewItemPrice.setText(String.valueOf(clickedRow.getNewPrice()));
    }
    public void alert(String displayMsg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        alert.setContentText(displayMsg);

        alert.showAndWait();
    }
    public void saveNewItemCode(){
        try {
            FileOutputStream itemCodes = new FileOutputStream("ItemCode.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemCodes);
            outputStream.writeObject(itemCodeList);
            outputStream.close();
            itemCodes.close();

            FileWriter writeFile = new FileWriter("Iterm Code.txt");                //save file to read
            for (String i : itemCodeList.keySet()) {
                writeFile.write(i+ " : " + itemCodeList.get(i)+" :  RS. " + priceList.get(i)+"\n");
                writeFile.flush();
            }
            writeFile.close();
        }catch (Exception e){
            System.out.println("Error in Item Code saving 1.");
        }
        try {
            FileOutputStream itemPrice = new FileOutputStream("ItemPrice.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemPrice);
            outputStream.writeObject(priceList);
            outputStream.close();
            itemPrice.close();
            Stage currentStage = (Stage) btAddNewItems.getScene().getWindow();
            currentStage.close();

        }catch (Exception e){
            System.out.println("Error in Item Code saving 2.");
        }


    }
    public void goToRemoveTable() throws IOException {

        // close the current stage
        Stage currentStage = (Stage) btRemoveTable.getScene().getWindow();
        currentStage.close();

        // Load the FXML file for the new window
        Parent root = FXMLLoader.load(getClass().getResource("RemoveItemCode.fxml"));

        // Create a new scene and set it in a new stage
        Stage newStage = new Stage();
        newStage.setTitle("Remove Item");
        newStage.setScene(new Scene(root, 600, 400));

        // Show the new stage
        newStage.show();
    }
    public void goToChangePrice() throws IOException {
        // close the current stage
        Stage currentStage = (Stage) btEditPrice.getScene().getWindow();
        currentStage.close();

        // Load the FXML file for the new window
        Parent root = FXMLLoader.load(getClass().getResource("PriceEdit.fxml"));

        // Create a new scene and set it in a new stage
        Stage newStage = new Stage();
        newStage.setTitle("Change Price");
        newStage.setScene(new Scene(root, 600, 400));

        // Show the new stage
        newStage.show();
    }

}
