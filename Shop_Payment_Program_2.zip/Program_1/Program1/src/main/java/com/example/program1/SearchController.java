package com.example.program1;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;

import static com.example.program1.HelloController.searchCodes;


public class SearchController {
    @FXML
    private TextArea taSearchItems;
    public void initialize(){
        for (String item : searchCodes.keySet()) {
            taSearchItems.setText(taSearchItems.getText() + "\n" + item + " : " + searchCodes.get(item));

        }           //print what matches to your search
        if (searchCodes.isEmpty()) {
            alert("Nothing Found! ");
        }
    }
    public void alert(String displayMsg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        alert.setContentText(displayMsg);

        alert.showAndWait();
    }
}
