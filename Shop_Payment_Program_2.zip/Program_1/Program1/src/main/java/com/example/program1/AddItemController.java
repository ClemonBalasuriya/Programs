package com.example.program1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static com.example.program1.HelloController.*;

public class AddItemController {
    @FXML
    private Button btAdd;

    @FXML
    private TableColumn<addItemTable, String> colAddItem;

    @FXML
    private TableColumn<addItemTable, String> colAddItemCode;

    @FXML
    private TableColumn<addItemTable, Integer> colAddQty;

    @FXML
    private TableView<addItemTable> tbAddItem;

    @FXML
    private TextField tfAddItemCode;

    @FXML
    private TextField tfAddQty;
    @FXML
    private TextField tfSearch;

    public void initialize(){
        AtomicReference<String> item_code = new AtomicReference<>("0");
        AtomicInteger item_qty = new AtomicInteger();
        tfAddItemCode.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfAddItemCode.getText().isEmpty() && !tfAddItemCode.getText().equals("0")) {
                    tfAddQty.requestFocus();

                }
            }
        });
        tfAddQty.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfAddQty.getText().isEmpty() && !tfAddQty.getText().equals("0") && !tfAddItemCode.getText().isEmpty() && !tfAddItemCode.getText().equals("0")) {
                    try{
                        item_code.set(tfAddItemCode.getText());
                        item_qty.set(Integer.parseInt(tfAddQty.getText()));

                    }catch (Exception e){
                        tfAddQty.clear();
                        tfAddQty.requestFocus();
                        return;
                    }
                    for (String item: itemCodeList.keySet() ) {

                        if (item.equals(item_code.toString())) {
                            int availableQuantity;
                            try{
                                availableQuantity = quantityList.get(item);
                            }catch (Exception e){
                                availableQuantity=0;
                            }



                            quantityList.put(item_code.toString(), ((Integer.parseInt(item_qty.toString()))+availableQuantity));

                            colAddItemCode.setCellValueFactory(cellData -> cellData.getValue().addItemCodeProperty());
                            colAddItem.setCellValueFactory(cellData -> cellData.getValue().addItemProperty());
                            colAddQty.setCellValueFactory(cellData -> cellData.getValue().addQtyProperty().asObject());

                            /*ObservableList<addItemTable> currentTableData = tbAddItem.getItems();
                            String currentItemId = tfAddItemCode.getText();

                            for (addItemTable items : currentTableData) {
                                if (items.getAddItemCode().equals(currentItemId)) {
                                    alert("Edit item what you change before.");
                                    items.setAddQty(Integer.parseInt(tfAddQty.getText()));

                                    tbAddItem.setItems(FXCollections.observableArrayList(currentTableData));
                                    tfAddItemCode.clear();
                                    tfAddQty.clear();
                                    tfAddItemCode.requestFocus();
                                    return;
                                }

                            }*/
                            addItemTable addItems = new addItemTable(item_code.toString(),itemCodeList.get(item),Integer.parseInt(item_qty.toString()));
                            tbAddItem.getItems().add(addItems);
                            tfAddItemCode.clear();
                            tfAddQty.clear();
                            tfAddItemCode.requestFocus();
                            break;

                        }
                    }

                }
            }
        });

    }

    public void saveNewItemCode(){


        try {
            FileOutputStream itemCodes = new FileOutputStream("ItemQuantity.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemCodes);
            outputStream.writeObject(quantityList);
            outputStream.close();
            itemCodes.close();

            Stage currentStage = (Stage) btAdd.getScene().getWindow();
            currentStage.close();

        }catch (Exception e){
            System.out.println("Error in Item Code saving .");
        }

    }

}


