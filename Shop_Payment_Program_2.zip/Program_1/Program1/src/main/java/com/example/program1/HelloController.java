package com.example.program1;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.print.PageLayout;
import javafx.print.PrinterJob;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class HelloController {
    static HashMap<String,String> itemCodeList = new HashMap<>();
    static HashMap<String,Double> priceList = new HashMap<>();
    static HashMap<String,Integer> quantityList = new HashMap<>();
     static HashMap<String,String> searchCodes = new HashMap<>();

    int discount;

    @FXML
    private Button btAddItems;

    @FXML
    private Button btCheck;

    @FXML
    private Button btEditItemCodes;

    @FXML
    private Button btPurches;

    @FXML
    private Button btSearch;

    @FXML
    private Button btSetDiscount;

    @FXML
    private TableColumn<Table, Integer> colDiscount;

    @FXML
    private TableColumn<Table, String> colItem;

    @FXML
    private TableColumn<Table, String> colItemCode;

    @FXML
    private TableColumn<Table, Double> colPrice;

    @FXML
    private TableColumn<Table, Integer> colQty;

    @FXML
    private Label lbDiscount;

    @FXML
    private Label lbTotal;

    @FXML
    private TableView<Table> tbReceipt;

    @FXML
    private TextField tfCheck;

    @FXML
    private TextField tfCode;

    @FXML
    private TextField tfQty;

    @FXML
    private TextField tfSearch;

    @FXML
    private TextField tfSetDiscount;
    @FXML
    private TextField tfAddItemCode;

    @FXML
    private TextField tfAddItemName;








    public void initialize() throws IOException {
        try {
            FileInputStream itemCodes = new FileInputStream("ItemCode.txt");
            ObjectInputStream inputStream = new ObjectInputStream(itemCodes);
            HashMap<String,String> CodeList = (HashMap<String, String>) inputStream.readObject();
            inputStream.close();
            itemCodes.close();
            for (String item : CodeList.keySet()) {
                itemCodeList.put(item,CodeList.get(item));
            }
        }catch (Exception e){
            System.out.println("Item code file load Error 1.");
        }
        try {
            FileInputStream itemCodes = new FileInputStream("ItemPrice.txt");
            ObjectInputStream inputStream = new ObjectInputStream(itemCodes);
            HashMap<String,Double> CodeList = (HashMap<String, Double>) inputStream.readObject();
            inputStream.close();
            itemCodes.close();
            for (String item : CodeList.keySet()) {
                priceList.put(item,CodeList.get(item));
            }
        }catch (Exception e){
            System.out.println("Item code file load Error 2.");
        }
        try {
            FileInputStream itemCodes = new FileInputStream("ItemQuantity.txt");
            ObjectInputStream inputStream = new ObjectInputStream(itemCodes);
            HashMap<String,Integer> CodeList = (HashMap<String, Integer>) inputStream.readObject();
            inputStream.close();
            itemCodes.close();
            for (String item : CodeList.keySet()) {
                quantityList.put(item,CodeList.get(item));
            }
        }catch (Exception e){
            System.out.println("Item code file load Error 3.");
        }

        AtomicReference<Double> totalDiscount = new AtomicReference<>(0.0);
        AtomicReference<Double> total = new AtomicReference<>(0.0);
        AtomicReference<String> item_code = new AtomicReference<>("0");
        AtomicInteger item_qty = new AtomicInteger();
        tfCode.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {
                if (!tfCode.getText().isEmpty() && !tfCode.getText().equals("0")) {
                    tfQty.requestFocus();
                }
            }

        });
        tfQty.setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.ENTER) {

                if (!tfCode.getText().isEmpty() && !tfQty.getText().isEmpty() && !tfCode.getText().equals("0")) {

                    try {
                        item_code.set(tfCode.getText());
                        item_qty.set(Integer.parseInt(tfQty.getText()));
                    } catch (Exception e) {
                        tfQty.clear();
                        return;
                    }


                    boolean not_available = true;
                    int availableQuantity = 0;
                    for (String item : quantityList.keySet()) {
                        if (item_code.toString().equals(item)) {
                            not_available = false;
                            availableQuantity = quantityList.get(item);
                            break;

                        }
                    }

                    if (not_available) {
                        alert("Out of stock");
                    } else if (Integer.parseInt(item_qty.toString()) <=availableQuantity) {
                        quantityList.put(item_code.toString(), (availableQuantity - (Integer.parseInt(item_qty.toString()))));
                        Double itemPrice = priceList.get(item_code.toString());
                        Double discountPrice = (itemPrice / 100) * discount;
                        totalDiscount.set(totalDiscount.get() + discountPrice);
                        itemPrice -= discountPrice;
                        itemPrice *= Integer.parseInt(item_qty.toString());

                        total.set(total.get() + itemPrice);
                        lbDiscount.setText(totalDiscount.toString());


                        colItemCode.setCellValueFactory(cellData -> cellData.getValue().itemCodeProperty());
                        colItem.setCellValueFactory(cellData -> cellData.getValue().itemProperty());
                        colQty.setCellValueFactory(cellData -> cellData.getValue().quantityProperty().asObject());
                        colDiscount.setCellValueFactory(cellData -> cellData.getValue().discountProperty().asObject());
                        colPrice.setCellValueFactory(cellData -> cellData.getValue().priceProperty().asObject());

                        /*ObservableList<Table> currentTableData = tbReceipt.getItems();
                        String currentItemId = tfCode.getText();

                        for (Table item : currentTableData) {
                            if (item.getItemCodes().equals(currentItemId)) {
                                alert("Edit item what you add before.");
                                item.setQty(Integer.parseInt(tfQty.getText()));
                                item.setPrice(Integer.parseInt(item_qty.toString()));

                                // Set the updated data to the table view
                                tbReceipt.setItems(FXCollections.observableArrayList(currentTableData));
                                tfCode.clear();
                                tfQty.clear();
                                tfCode.requestFocus();
                                return;
                            }
                        }*/
                        Table addItems = new Table(item_code.toString(), itemCodeList.get(item_code.toString()), Integer.parseInt(item_qty.toString()), discount, itemPrice);
                        tbReceipt.getItems().add(addItems);
                        tfCode.clear();
                        tfQty.clear();
                        tfCode.requestFocus();


                    } else {
                        alert("Limited stock. Only " + availableQuantity + " items.");
                    }
                }



            }

        });



    }
    public void displayAddItemCodes() throws IOException {

        // Load the FXML file for the new window
        Parent root = FXMLLoader.load(getClass().getResource("EditItemCode.fxml"));

        // Create a new scene and set it in a new stage
        Stage newStage = new Stage();
        newStage.setTitle("New Window");
        newStage.setScene(new Scene(root, 600, 400));

        // Show the new stage
        newStage.show();
    }


    public void goToAddItemTable() throws IOException {

        // Load the FXML file for the new window
        Parent root = FXMLLoader.load(getClass().getResource("AddItems.fxml"));

        // Create a new scene and set it in a new stage
        Stage newStage = new Stage();
        newStage.setTitle("Add Quantity");
        newStage.setScene(new Scene(root, 600, 400));

        // Show the new stage
        newStage.show();
    }
    public void alert(String displayMsg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        alert.setContentText(displayMsg);

        alert.showAndWait();
    }
    public void getDiscount(){
        try{
            discount = Integer.parseInt(tfSetDiscount.getText());
        }catch (Exception e){
            tfSetDiscount.setText("0");
            discount =0;
        }


    }

    public void purchase() {
        try {
            FileOutputStream itemCodes = new FileOutputStream("ItemCode.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemCodes);
            outputStream.writeObject(itemCodeList);
            outputStream.close();
            itemCodes.close();

            FileWriter writeFile = new FileWriter("Iterm Code.txt");                //save file to read
            for (String i : itemCodeList.keySet()) {
                writeFile.write(i+ " : " + itemCodeList.get(i)+" :  RS. " + priceList.get(i)+"\n");
                writeFile.flush();
            }
            writeFile.close();
        }catch (Exception e){
            System.out.println("Error in Item Code saving 1.");
        }

        try {
            FileOutputStream itemCodes = new FileOutputStream("ItemQuantity.txt");         //save hashmap to read machine
            ObjectOutputStream outputStream  = new ObjectOutputStream(itemCodes);
            outputStream.writeObject(quantityList);
            outputStream.close();
            itemCodes.close();

            if (tbReceipt.getItems().isEmpty()) return;

            alert("Items purchase successfully.");
            tbReceipt.getItems().clear();


        }catch (Exception e){
            System.out.println("Error in Item Code saving 2.");
        }

    }
    public void search_itermCode() throws IOException {
        System.out.print("Enter the item name or code: ");
        String item_nameOrCode = tfSearch.getText().toString();
        if (!item_nameOrCode.isEmpty()) {
            for (String item : itemCodeList.keySet()) {
                if (item.toLowerCase().matches(".*" + item_nameOrCode.toLowerCase() + ".*") || itemCodeList.get(item).toLowerCase().matches(".*" + item_nameOrCode.toLowerCase() + ".*")) {
                    searchCodes.put(item, itemCodeList.get(item));
                }
            }
        }

        Parent root = FXMLLoader.load(getClass().getResource("Search.fxml"));

        // Create a new scene and set it in a new stage
        Stage newStage = new Stage();
        newStage.setTitle("Remove Item");
        newStage.setScene(new Scene(root, 600, 400));

        // Show the new stage
        newStage.show();





    }
    public void check(){
        boolean notAvailable = true;
        if(!tfCheck.getText().isEmpty()){
            for (String item: quantityList.keySet()){
                if (item.equals(tfCheck.getText().toString())){
                    int availableQty = quantityList.get(item);
                    if (availableQty>0){
                        alert(item+" : "+itemCodeList.get(item)+" : "+availableQty);
                    }else alert("Out of Stock");
                    notAvailable=false;
                    break;
                }
            }
            if (notAvailable) alert("Not available.");
        }
    }

}
