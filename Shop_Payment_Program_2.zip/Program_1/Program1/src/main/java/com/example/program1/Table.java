package com.example.program1;

import javafx.beans.property.*;

public class Table {
    private final  StringProperty itemCode;
    private final  StringProperty item;
    private final IntegerProperty quantity;
    private final  IntegerProperty discount;
    private final DoubleProperty price;

    public StringProperty itemCodeProperty() {
        return itemCode;
    }

    public StringProperty itemProperty() {
        return item;
    }

    public IntegerProperty quantityProperty() {
        return quantity;
    }

    public IntegerProperty discountProperty() {
        return discount;
    }
    public String getItemCodes() {
        return itemCode.get();
    }



    public void setQty(int newQty) {
        this.quantity.set(newQty);
    }
    public void setPrice(int newPrice) {
        this.quantity.set(newPrice);
    }



    public DoubleProperty priceProperty() {
        return price;
    }

    public Table(String itemCode, String item, int quantity, int discount, double price) {
        this.itemCode = new SimpleStringProperty(itemCode);
        this.item = new SimpleStringProperty(item);
        this.quantity = new SimpleIntegerProperty(quantity);
        this.discount = new SimpleIntegerProperty(discount);
        this.price = new SimpleDoubleProperty(price);
    }

}
