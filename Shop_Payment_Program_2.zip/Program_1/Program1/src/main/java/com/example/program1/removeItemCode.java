package com.example.program1;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class removeItemCode {
    private final StringProperty removeItemCode;
    private final  StringProperty removeItem;
    public removeItemCode(String removeItemCode, String removeItem) {
        this.removeItemCode = new SimpleStringProperty(removeItemCode);
        this.removeItem = new SimpleStringProperty(removeItem);

    }

    public String getRemoveItemCode() {
        return removeItemCode.get();
    }

    public StringProperty removeItemCodeProperty() {
        return removeItemCode;
    }

    public String getNewItem() {
        return removeItem.get();
    }

    public StringProperty removeItemProperty() {
        return removeItem;
    }

}




