package com.example.program1;

import javafx.beans.property.*;

public class newAddTable {
    public void setNewItemCode(String newItemCode) {
        this.newItemCode.set(newItemCode);
    }

    public void setNewItem(String newItem) {
        this.newItem.set(newItem);
    }

    public void setNewPrice(int newPrice) {
        this.newPrice.set(newPrice);
    }

    public newAddTable(String newItemCode, String newItem, Integer newPrice) {
        this.newItemCode = new SimpleStringProperty(newItemCode);
        this.newItem = new SimpleStringProperty(newItem);
        this.newPrice = new SimpleIntegerProperty(newPrice);

    }

    public String getNewItemCode() {
        return newItemCode.get();
    }

    public StringProperty newItemCodeProperty() {
        return newItemCode;
    }

    public String getNewItem() {
        return newItem.get();
    }

    public StringProperty newItemProperty() {
        return newItem;
    }

    public int getNewPrice() {
        return newPrice.get();
    }

    public IntegerProperty newPriceProperty() {
        return newPrice;
    }

    private final StringProperty newItemCode;
    private final  StringProperty newItem;
    private final IntegerProperty newPrice;
}
