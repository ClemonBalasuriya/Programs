package com.example.program1;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class addItemTable {
    public void setAddItem(String newItem) {
        this.addItem.set(newItem);
    }

    public void setAddQty(int newPrice) {
        this.addQty.set(newPrice);
    }

    public addItemTable(String newItemCode, String newItem, Integer qty) {
        this.addItemCode = new SimpleStringProperty(newItemCode);
        this.addItem = new SimpleStringProperty(newItem);
        this.addQty = new SimpleIntegerProperty(qty);

    }

    public String getAddItemCode() {
        return addItemCode.get();
    }

    public StringProperty addItemCodeProperty() {
        return addItemCode;
    }

    public String getAddItem() {
        return addItem.get();
    }

    public StringProperty addItemProperty() {
        return addItem;
    }

    public int getAddQty() {
        return addQty.get();
    }

    public IntegerProperty addQtyProperty() {
        return addQty;
    }

    private final StringProperty addItemCode;
    private final  StringProperty addItem;
    private final IntegerProperty addQty;
}
