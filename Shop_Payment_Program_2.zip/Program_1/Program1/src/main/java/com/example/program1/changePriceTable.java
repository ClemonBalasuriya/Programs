package com.example.program1;

import javafx.beans.property.*;

public class changePriceTable {
    private final StringProperty itemCode;
    private final  StringProperty item;
    private final DoubleProperty price;
    public String getChangePriceItemCode() {
        return itemCode.get();
    }
    public double getChangePrice() {
        return price.get();
    }

    public StringProperty itemCodeProperty() {
        return itemCode;
    }

    public StringProperty itemProperty() {
        return item;
    }


    public DoubleProperty priceProperty() {
        return price;
    }

    public changePriceTable(String itemCode, String item,  double price) {
        this.itemCode = new SimpleStringProperty(itemCode);
        this.item = new SimpleStringProperty(item);
        this.price = new SimpleDoubleProperty(price);
    }
    public void setChangePriceItem(String newItem) {
        this.item.set(newItem);
    }

    public void setChangePrice(Double newPrice) {
        this.price.set(newPrice);
    }

}
